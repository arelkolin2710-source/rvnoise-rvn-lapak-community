# RVNOISE - Lapak Community

## Setup Firebase (project rvnoise-lapak)
1. Authentication > Sign-in method: aktifkan Email/Password dan Google.
2. Authentication > Settings > Authorized domains: tambahkan domain hosting kamu (tanpa https://).
3. Firestore Database: buat database, tab Rules > tempel isi firestore.rules > Publish.
4. Deploy folder ini ke Netlify/Vercel/Firebase Hosting (harus HTTPS).

## Dashboard staff
Buka https://DOMAINMU/#rvnoiseadmin (login sendiri, terpisah dari aplikasi).
- Admin = Gmail areelkolin@gmail.com yang sudah terverifikasi. Cara paling mudah: tombol "Masuk dengan Google".
- Username staff: rvnois. Untuk login dengan sandi, tekan "Atur / lupa sandi" (link dikirim ke Gmail admin), lalu masuk dengan rvnois + sandi baru.
- Sandi tidak ditanam di kode. Atur sendiri lewat Firebase.
- Pertama kali dashboard dibuka, akun official @rvnoise dibuat otomatis (dikelola dari tab Official).

## Catatan
- Menghapus data pengguna dari dashboard tidak menghapus akun loginnya di Firebase Authentication (hapus manual di Console > Authentication > Users).
- Live baru kamera + status; siaran ke penonton butuh server WebRTC.

## Versi 4
- Dashboard staff: buka tab "Hadiah dan aset" sekali agar katalog (hadiah dan aset investasi) terbentuk di Firestore. Harga bisa diubah di sana.
- Hadiah dibeli dengan noisevn dan masuk inventaris (bukan saldo). Aset investasi tampil sebagai lencana profil.
- Musik postingan hanya menerima link Spotify, diputar otomatis 30 detik saat postingan terlihat.
- Lencana Artis (diberikan admin) membuka unggah lagu di ikon Musik.

## Versi 5 (musik latar)
- Info musik tampil otomatis di bawah username (ikon equalizer + judul lagu), tanpa banner dan tanpa ketuk.
- Musik Spotify diputar otomatis saat postingan berada di tengah layar, berhenti sendiri setelah 30 detik atau saat postingan lewat.
- Ketuk baris musik untuk jeda manual. Kalau browser memblokir suara, muncul ajakan "Ketuk layar", ketukan pertama di mana saja langsung memutar.

## Versi 6 (fitur besar)
Berkas baru: `features.js` (wajib ikut diunggah bersama app.js). Rules Firestore berubah, **publish ulang `firestore.rules`**.

- Chat: tab Semua / Permintaan / Arsip, jam tiap pesan, pemisah tanggal (Hari ini, Kemarin), grup dan Family (nama, foto, anggota), stiker dan GIF pribadi.
- Game RVNMATCH (ikon controller di halaman Pesan): cari pacar, besti, atau relationship. Saling suka langsung terbuka chat.
- RVNREELS: ikon film di sebelah tombol +, tontonan vertikal ala IG/TikTok, unggah video maks 100 MB.
- Profil: sorotan dari arsip story (nama + cover), kotak Valuasi Kekayaan, banner Spotify lagu favorit, status hubungan.
- Pengaturan (ikon di profil): warna aplikasi, status hubungan, Spotify, privasi pesan, info akun, hapus akun mandiri, keluar.
- Komentar berbalas di postingan, tweet, carousel, dan story (semua orang bisa melihat).
- Live: video + suara lewat WebRTC (satu host ke maks 12 penonton).
- Keamanan otomatis: filter kata kasar (di aplikasi dan di rules Firestore), tombol laporan, tab Moderasi di dashboard staf.
- Akun resmi / admin bisa menyematkan postingan di semua beranda (ikon pin di kartu postingan).
- Beranda: tarik ke bawah atau ketuk ikon segarkan untuk mengacak ulang urutan, banner "postingan baru".
- Foto carousel otomatis dipotong persegi 1:1.

### Mengaktifkan upload video reels (Cloudinary, gratis)
Firestore tidak bisa menyimpan video, jadi video diunggah ke Cloudinary (paket gratis, maks 100 MB per video).
1. Daftar di cloudinary.com (gratis). Catat **Cloud name** di Dashboard.
2. Settings, Upload, Upload presets, Add upload preset. Ubah **Signing mode** menjadi **Unsigned**, lalu simpan. Catat nama preset.
3. Buka `app.js`, cari `const CLOUDINARY={cloud:'',preset:''}` lalu isi, contoh `{cloud:'namaanda',preset:'rvnoise_unsigned'}`.
4. Deploy ulang. Tanpa langkah ini, reels tetap bisa diposting memakai link .mp4 atau YouTube.

### Catatan
- Live memakai server STUN gratis. Sebagian jaringan seluler yang ketat bisa gagal tersambung tanpa server TURN.
- Hapus akun mandiri menghapus postingan, story, koleksi, dan profil. Riwayat chat tidak ikut terhapus.
